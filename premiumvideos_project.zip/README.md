# premiumvideos - Starter project

You asked for a modern site named **premiumvideos**. This is a ready-to-run starter project (backend + frontend) that supports:
- Free user signup/login
- Admin video upload
- Pay-per-video using Razorpay (UPI + Card)
- Protected streaming (HTTP Range support)

---

## What is included
- `server.js` - Node/Express backend (APIs + streaming)
- `package.json`
- `public/` - static frontend (modern simple UI)
- `.env.example` - env variables
- `README.md` - this file

---

## Quick local setup (development)

1. Install Node.js and MySQL.
2. Create the database and tables (MySQL):

```sql
CREATE DATABASE video_store CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE video_store;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(150) UNIQUE,
  password VARCHAR(255),
  is_admin TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE videos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200),
  description TEXT,
  filename VARCHAR(300),
  price INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  video_id INT,
  payment_id VARCHAR(200),
  status VARCHAR(32),
  amount INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

3. Copy `.env.example` to `.env` and fill values.
4. Install dependencies:

```bash
npm install
```

5. Start server:

```bash
npm start
```

- Backend runs on port defined in `.env` (default 5000).
- Static files are served at `/static/*`. Open `http://localhost:5000/static/` for frontend.

---

## Deploying to the public web (recommended approach)

This project is two parts: **frontend (static)** and **backend (Node API + streaming)**.
I recommend:

### Option A — Free / easy (Render + Firebase)
1. **Deploy backend (server.js) to Render.com or Railway.app**
   - Create a new Web Service on Render, connect repo or upload code.
   - Set environment variables from `.env`.
   - Start command: `npm start`.
   - Render will give you a HTTPS URL for the API (e.g. `https://premium-backend.onrender.com`).

2. **Deploy frontend to Firebase Hosting**
   - Install Firebase CLI: `npm i -g firebase-tools`
   - `firebase init hosting` -> select `public` folder or point to a small static build. For simplicity, you can host the `public/` folder and set rewrites to proxy API calls to your Render backend or configure CORS.
   - `firebase deploy` -> you'll get a `https://<your-site>.web.app` URL.

3. Update frontend `index.html` / JS to use your backend domain.

### Option B — Single host (DigitalOcean / VPS)
- Host both backend and static files on one VPS with a domain and Nginx reverse proxy.
- Configure SSL (Let's Encrypt).
- More setup but full control.

---

## Notes & next steps
- Replace `REPLACE_WITH_YOUR_RAZORPAY_KEY_ID` in the frontend with your Razorpay key (or better: inject from server).
- In production, verify Razorpay payment signatures on server using `razorpay.utils.verifyPaymentSignature`.
- For many/big videos, use S3 (AWS) + signed URLs or a CDN.
- I can prepare a GitHub repo and push this code for you, and I can give step-by-step support to deploy to Render + Firebase and get a live URL. If you want, I can also prepare a Firebase Cloud Functions version (host entire app on Firebase) — tell me which hosting provider you prefer.

---

## Want me to deploy?
I can help you deploy. I cannot directly host using my account, but I will:
1. Create a ZIP (done)
2. Give clear commands to run
3. If you provide your Render or Firebase project access (or perform the few clicks), I will give exact commands and config lines to paste.

Tell me which deployment option you prefer: **Render + Firebase**, **VPS (Nginx)**, or **Firebase-only (Cloud Functions)**.
